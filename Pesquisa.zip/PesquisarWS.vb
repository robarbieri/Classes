﻿Option Explicit On
Option Strict Off

Imports System
Imports System.Xml
Imports System.Web.Services.Protocols

Public Class Pesquisa

    Private WSaFinder As New aFinder.WebServices
    Private WSinfo As New InforMarketing.WEBServiceScore
    Private objAuthentication As aFinder.AuthHeader = New aFinder.AuthHeader

    Public Function Localizar(Optional ByVal strTipoRetorno As String = "HTML") As String

        Dim ResultAFinder As String = ""
        Dim ResultInfo As String = ""

        Try

            If Trim(strTelefone) <> "" Then
                If Len(Trim(strTelefone)) > 8 Then strTelefone = Left(strTelefone, 8)
                If Trim(strDDD) <> "" Then If Len(Trim(strDDD)) <> 2 Or IsNumeric(Trim(strDDD)) = False Then strDDD = ""
            End If

            If blnAFinder = True Then
                Localizar = Trim(LocalizarFinder())
            End If

            If blnInfo = True And Trim(ResultAFinder) = "" Then
                ResultInfo = LocalizarInfo()
                Localizar = FormatXMLInfo(ResultInfo)
            End If

            If Trim(Localizar) <> "" And UpperTrim(strTipoRetorno) = "HTML" Then Localizar = ReturnHTML(Localizar, "http://DBMIRROR/Intranet/result.xsl")

        Catch ex As Exception

            Localizar = ""

        End Try

    End Function

    Private Function LocalizarFinder() As String

        Dim intSentido As Integer

        Try

            WSaFinder.Credentials = System.Net.CredentialCache.DefaultCredentials
            objAuthentication.Username = strUserFinder
            objAuthentication.Password = strPassFinder
            WSaFinder.AuthHeaderValue = objAuthentication

            If blnBuscaAut = True Then

                LocalizarFinder = WSaFinder.BuscaAutXml(strUF, _
                                                        strCidade, _
                                                        strBairro, _
                                                        strEndereco, _
                                                        strNumero, _
                                                        strComplemento, _
                                                        strCEP, _
                                                        strNome, _
                                                        strCPF, _
                                                        strDDD, _
                                                        strTelefone, _
                                                        intRegistros, _
                                                        blnHigienizar, _
                                                        strBases).OuterXml

            ElseIf blnBuscaCPF = True Then

                LocalizarFinder = WSaFinder.BuscaCPFXml("", _
                                                        strCPF, _
                                                        intRegistros, _
                                                        strBases).OuterXml

            ElseIf blnProximidades = True Then

                If Trim(strComplemento) <> "" Then intSentido = 3

                LocalizarFinder = WSaFinder.BuscaProximidadesXml(strUF, _
                                                                 strCidade, _
                                                                 strBairro, _
                                                                 strEndereco, _
                                                                 strNumero, _
                                                                 strComplemento, _
                                                                 strCEP, _
                                                                 intRegistros, _
                                                                 intSentido).OuterXml

            Else

                LocalizarFinder = WSaFinder.BuscaXml(strUF, _
                                                     strCidade, _
                                                     strBairro, _
                                                     strEndereco, _
                                                     strNumero, _
                                                     strComplemento, _
                                                     strCEP, _
                                                     strNome, _
                                                     strCPF, _
                                                     strDDD, _
                                                     strTelefone, _
                                                     intRegistros, _
                                                     strBases).OuterXml

            End If

        Catch ex As Exception

            LocalizarFinder = ""

        End Try

    End Function

    Private Function LocalizarInfo() As String

        Try

            If Trim(strAuthInfo) = "" Then strAuthInfo = WSinfo.getLogin("credicard1", "caneta", "hargos")

            LocalizarInfo = WSinfo.getLista_Dados_String_XML("credicard1", strAuthInfo, strCPF)

        Catch ex As Exception

            LocalizarInfo = ""

        End Try

    End Function

    Public Sub New()

        strUserFinder = ""
        strPassFinder = ""
        strAuthInfo = ""
        strUF = ""
        strCidade = ""
        strBairro = ""
        strEndereco = ""
        strNumero = ""
        strComplemento = ""
        strCEP = ""
        strNome = ""
        strCPF = ""
        strDDD = ""
        strTelefone = ""
        intRegistros = 0
        strBases = ""
        blnHigienizar = False
        blnBuscaAut = False
        blnProximidades = False
        blnAFinder = False
        blnInfo = False

    End Sub

    'Propriedades
    Public Property BuscarAFinder() As Boolean
        Get
            Return blnAFinder
        End Get
        Set(ByVal Value As Boolean)
            If blnAFinder <> Value Then blnAFinder = Value
        End Set
    End Property

    Public Property BuscarInfo() As Boolean
        Get
            Return (blnInfo)
        End Get
        Set(ByVal Value As Boolean)
            If blnInfo <> Value Then blnInfo = Value
        End Set
    End Property

    Public Property UserFinder() As String
        Get
            Return strUserFinder
        End Get
        Set(ByVal Value As String)
            If strUserFinder <> Value Then strUserFinder = Value
        End Set
    End Property

    Public Property PassFinder() As String
        Get
            Return strPassFinder
        End Get
        Set(ByVal Value As String)
            If strPassFinder <> Value Then strPassFinder = Value
        End Set
    End Property

    Public Property AuthInfo() As String
        Get
            Return strAuthInfo
        End Get
        Set(ByVal Value As String)
            If strAuthInfo <> Value Then strAuthInfo = Value
        End Set
    End Property

    Public Property BuscaAut() As Boolean
        Get
            Return blnBuscaAut
        End Get
        Set(ByVal Value As Boolean)
            If blnBuscaAut <> Value Then blnBuscaAut = Value
        End Set
    End Property

    Public Property BuscaCPF() As Boolean
        Get
            Return blnBuscaCPF
        End Get
        Set(ByVal Value As Boolean)
            If blnBuscaCPF <> Value Then blnBuscaCPF = Value
        End Set
    End Property

    Public Property Proximidades() As Boolean
        Get
            Return blnProximidades
        End Get
        Set(ByVal Value As Boolean)
            If blnProximidades <> Value Then blnProximidades = Value
        End Set
    End Property

    Public Property UF() As String
        Get
            Return strUF
        End Get
        Set(ByVal Value As String)
            If strUF <> Value Then strUF = UpperTrim(Value)
        End Set
    End Property

    Public Property Cidade() As String
        Get
            Return strCidade
        End Get
        Set(ByVal Value As String)
            If strCidade <> Value Then strCidade = UpperTrim(Value)
        End Set
    End Property

    Public Property Bairro() As String
        Get
            Return strBairro
        End Get
        Set(ByVal Value As String)
            If strBairro <> Value Then strBairro = UpperTrim(Value)
        End Set
    End Property

    Public Property Endereco() As String
        Get
            Return strEndereco
        End Get
        Set(ByVal Value As String)
            If strEndereco <> Value Then strEndereco = UpperTrim(Value)
        End Set
    End Property

    Public Property Numero() As String
        Get
            Return strNumero
        End Get
        Set(ByVal Value As String)
            If strNumero <> Value Then strNumero = UpperTrim(Value)
        End Set
    End Property

    Public Property Complemento() As String
        Get
            Return strComplemento
        End Get
        Set(ByVal Value As String)
            If strComplemento <> Value Then strComplemento = UpperTrim(Value)
        End Set
    End Property

    Public Property CEP() As String
        Get
            Return strCEP
        End Get
        Set(ByVal Value As String)
            If strCEP <> Value Then strCEP = UpperTrim(SoNumeros(Value))
        End Set
    End Property

    Public Property Nome() As String
        Get
            Return strNome
        End Get
        Set(ByVal Value As String)
            If strNome <> Value Then strNome = UpperTrim(Value)
        End Set
    End Property

    Public Property CPF() As String
        Get
            Return strCPF
        End Get
        Set(ByVal Value As String)
            If strCPF <> Value Then strCPF = UpperTrim(SoNumeros(Value))
        End Set
    End Property

    Public Property DDD() As String
        Get
            Return strDDD
        End Get
        Set(ByVal Value As String)
            If strDDD <> Value Then strDDD = UpperTrim(SoNumeros(Value))
        End Set
    End Property

    Public Property Telefone() As String
        Get
            Return strTelefone
        End Get
        Set(ByVal Value As String)
            If strTelefone <> Value Then strTelefone = UpperTrim(SoNumeros(Value))
        End Set
    End Property

    Public Property Registros() As String
        Get
            Return intRegistros
        End Get
        Set(ByVal Value As String)
            If intRegistros <> Value Then intRegistros = Value
        End Set
    End Property

    Public Property Higienizar() As String
        Get
            Return blnHigienizar
        End Get
        Set(ByVal Value As String)
            If blnHigienizar <> Value Then blnHigienizar = Value
        End Set
    End Property

    Public Property Bases() As String
        Get
            Return strBases
        End Get
        Set(ByVal Value As String)
            If strBases <> Value Then strBases = UpperTrim(Value)
        End Set
    End Property

End Class