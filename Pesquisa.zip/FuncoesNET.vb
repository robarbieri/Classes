Imports System.IO
Imports System.Xml
Imports System.Xml.Xsl
Imports System.Text

Module FuncoesNET

    Public Function UpperTrim(ByVal strText As String) As String

        UpperTrim = Trim(UCase(strText))

    End Function

    Public Function SoNumeros(ByVal strDado As String) As String

        Dim x As Short = 0

        For x = 1 To Len(UpperTrim(strDado))
            If IsNumeric(Mid(UpperTrim(strDado), x, 1)) = False Then
                strDado = Trim(Replace(UpperTrim(strDado), Mid(UpperTrim(strDado), x, 1), ""))
            End If
        Next x

        SoNumeros = strDado

    End Function

    Public Function ReturnHTML(ByVal strXML As String, ByVal strPathXSL As String) As String

        Dim objXML As New XmlDocument
        Dim objXSL As New XslTransform
        Dim sb As New StringBuilder
        Dim sw As New StringWriter(sb)

        Try

            objXML.LoadXml(strXML)
            objXSL.Load(strPathXSL)

            objXSL.Transform(objXML, Nothing, sw, Nothing)

            ReturnHTML = sb.ToString

        Catch ex As Exception

            ReturnHTML = ""

        End Try

    End Function

    Public Function FormatXMLInfo(ByVal strXML As String) As String

        Dim strFones As String = ""
        Dim strEndereco As String = ""
        Dim arrEndereco() As String
        Dim strCPF As String = ""
        Dim strTipoEnd As String = ""
        Dim strEnd As String = ""
        Dim strNum As String = ""
        Dim strCompl As String = ""
        Dim strCEP As String = ""
        Dim strBairro As String = ""
        Dim strCidade As String = ""
        Dim strUF As String = ""
        Dim strNome As String = ""
        Dim arrDDD(50) As String
        Dim arrFones() As String
        Dim xmlDoc As New XmlDocument
        Dim x As Short = 0
        Dim y As Short = 0

        Try

            xmlDoc.LoadXml(strXML)

            y = xmlDoc.ChildNodes(0).ChildNodes.Count - 1

            For x = 0 To y

                Select Case UpperTrim(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(2).InnerXml)

                    Case "CPF"
                        strCPF = Mid("00000000000000" & UpperTrim(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml), Len("00000000000000" & UpperTrim(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml)) - 13)

                    Case "NOME"
                        strNome = UpperTrim(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml)

                    Case "ENDERECO RESIDENCIAL - A"
                        strEndereco = UpperTrim(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml)

                    Case "ENDERECO RESIDENCIAL - V"
                        If Trim(strEndereco) = "" Then strEndereco = UpperTrim(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml)

                    Case "ENDERECO RESIDENCIAL - G"
                        If Trim(strEndereco) = "" Then strEndereco = UpperTrim(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml)

                    Case "ENDERECO COMERCIAL - R"
                        If Trim(strEndereco) = "" Then strEndereco = UpperTrim(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml)

                    Case "TELEFONE RESIDENCIAL - A"
                        If Trim(strFones) <> "" Then strFones = strFones & " - "
                        strFones = strFones & UpperTrim(Replace(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml, "-", ""))

                    Case "TELEFONE RESIDENCIAL - V"
                        If Trim(strFones) <> "" Then strFones = strFones & " - "
                        strFones = strFones & UpperTrim(Replace(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml, "-", ""))

                    Case "TELEFONE RESIDENCIAL - G"
                        If Trim(strFones) <> "" Then strFones = strFones & " - "
                        strFones = strFones & UpperTrim(Replace(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml, "-", ""))

                    Case "TELEFONE COMERCIAL - R"
                        If Trim(strFones) <> "" Then strFones = strFones & " - "
                        strFones = strFones & UpperTrim(Replace(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml, "-", ""))

                    Case "TELEFONE CELULAR - 1"
                        If Trim(strFones) <> "" Then strFones = strFones & " - "
                        strFones = strFones & UpperTrim(Replace(xmlDoc.ChildNodes(0).ChildNodes(x).ChildNodes(3).InnerXml, "-", ""))

                End Select

            Next

            strFones = Replace(strFones, " ", "")
            arrFones = Split(Trim(strFones), "-")
            arrEndereco = Split(strEndereco, "-")
            strTipoEnd = Trim(arrEndereco(0))
            strEnd = Trim(arrEndereco(1)) & " " & Trim(arrEndereco(2))
            strNum = Trim(arrEndereco(3))
            strCompl = Trim(arrEndereco(4))
            strBairro = Trim(arrEndereco(5))
            strCidade = Trim(arrEndereco(6))
            strUF = Trim(arrEndereco(7))
            strCEP = Trim(arrEndereco(8))

            strXML = "<ROOT xmlns="""">"

            For x = 0 To UBound(arrFones)

                arrDDD(x) = Mid(Trim(arrFones(x)), 1, 2)
                arrFones(x) = Trim(Mid(arrFones(x), 3))

                strXML = strXML & "<XML ID=""" & Format(Now, "ddMMyyyhhmmss") & x & """"
                strXML = strXML & " DDD=""" & arrDDD(x) & """"
                strXML = strXML & " FONE=""" & arrFones(x) & """"
                strXML = strXML & " NOME=""" & strNome & """"
                strXML = strXML & " TIPO=""" & strTipoEnd & """"
                strXML = strXML & " ENDERECO=""" & strEnd & """"
                strXML = strXML & " NUMERO=""" & strNum & """"
                strXML = strXML & " COMPLEMENTO=""" & strCompl & """"
                strXML = strXML & " BAIRRO=""" & strBairro & """"
                strXML = strXML & " CIDADE=""" & strCidade & """"
                strXML = strXML & " UF=""" & strUF & """"
                strXML = strXML & " CEP=""" & strCEP & """"
                strXML = strXML & " CPF=""" & strCPF & """"
                strXML = strXML & " ACAO=""1"" TABLE=""TELEFONES"" />"

            Next x

            strXML = strXML & "</ROOT>"

            If Trim(strXML) = "<ROOT xmlns=""""></ROOT>" Then strXML = ""

            FormatXMLInfo = strXML

        Catch ex As Exception

            FormatXMLInfo = ""

        End Try

    End Function

End Module
